# Netdata internal checks

A debugging plugin (by default it is disabled)
