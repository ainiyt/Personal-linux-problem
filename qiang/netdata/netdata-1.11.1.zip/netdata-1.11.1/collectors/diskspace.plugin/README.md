# diskspace.plugin

This plugin monitors the disk space usage of mounted disks, under Linux.

> for disks performance monitoring, see the `proc` plugin, [here](../proc.plugin/#monitoring-disks)

