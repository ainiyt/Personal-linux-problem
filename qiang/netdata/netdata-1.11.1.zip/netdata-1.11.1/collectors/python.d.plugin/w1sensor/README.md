# w1sensor

Data from 1-Wire sensors.
On Linux these are supported by the wire, w1_gpio, and w1_therm modules.
Currently temperature sensors are supported and automatically detected.

Charts are created dynamically based on the number of detected sensors.

### configuration

For detailed configuration information please read [`w1sensor.conf`](w1sensor.conf) file.

---
