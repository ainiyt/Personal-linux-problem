# dns_query_time

This module provides DNS query time statistics.

**Requirement:**
* `python-dnspython` package

It produces one aggregate chart or one chart per DNS server, showing the query time.

---
