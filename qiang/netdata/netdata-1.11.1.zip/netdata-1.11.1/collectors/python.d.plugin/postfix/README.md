# postfix

Simple module executing `postfix -p` to grab postfix queue.

It produces only two charts:

1. **Postfix Queue Emails**
 * emails

2. **Postfix Queue Emails Size** in KB
 * size

Configuration is not needed.

---
