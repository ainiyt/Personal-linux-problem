# macos

Collects resource usage and performance data on MacOS systems
